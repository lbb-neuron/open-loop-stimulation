﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;
using Mcs.Usb;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace FB_Example.Properties
{
    class PyWrapper
    {
        private Queue<ChannelData> dataQueue;
        public Queue<uint[]> dataMessages;
        CMcsUsbListEntryNet DspPort;
        uint LockMask;

        string t_server;
        int t_port;
        string auth_key;
        int s_port;

        int n_ports = 20;

        private Thread clientThread;
        private static Socket[] clientSocket;

        public object _lock;

        public PyWrapper(CMcsUsbListEntryNet DspPort, uint LockMask, object l, int t_port, int s_port, string auth_key, int n_ports)
        {
            this.LockMask = LockMask;
            this.DspPort  = DspPort;
            _lock         = l;
            dataQueue = new Queue<ChannelData>();
            dataMessages = new Queue<uint[]>();

            this.n_ports = n_ports;
            clientSocket = new Socket[n_ports];

            clientThread = new Thread(Connect);
            clientThread.Start();
            this.t_server = "127.0.0.1";
            this.t_port   = t_port;
            this.auth_key = auth_key;
            this.s_port   = s_port;

        }

        public void Connect()
        {
            // Already connected?
            for(int i = 0; i < n_ports; i++)
                if (clientSocket[i] != null && clientSocket[i].Connected)
                    clientSocket[i].Close();

            try
            {
                string server = t_server;
                int servPort  = t_port;

                // Create new IPv4 Tcp Socket
                for (int i = 0; i < n_ports; i++)
                {
                    IPAddress servIPAddress = Dns.GetHostAddresses(server)[0];
                    IPEndPoint servEndPoint = new IPEndPoint(servIPAddress, servPort+i);

                    clientSocket[i] = new Socket(servIPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                    clientSocket[i].Connect(servEndPoint);

                    if (!clientSocket[i].Connected)
                        System.Diagnostics.Debug.WriteLine("Error Connecting to " + server);
                }
            }
            catch (SocketException se)
            {
                System.Diagnostics.Debug.WriteLine("Connect Exception: " + se.Message);
            }
        }

        public void Disconnect()
        {
            int flag = 0;
            for (int i = 0; i < n_ports; i++)
            {
                if (clientSocket[i] == null)
                {
                    if (flag == 0)
                    {
                        System.Diagnostics.Debug.WriteLine("You must first connect to a Server!");
                        flag = 1;
                    }
                    continue;
                }

                // Close socket
                if (clientSocket[i].Connected)
                    clientSocket[i].Shutdown(SocketShutdown.Both);
                clientSocket[i].Close();

                if (!clientSocket[i].Connected)
                    System.Diagnostics.Debug.WriteLine("You must first connect to a Server!");
            }
        }

        private async Task sendData(ChannelData data)
        {
            //Connect, if not yet connected
            for (int i = 0; i < n_ports; i++)
            {
                if (clientSocket[i] == null || !clientSocket[i].Connected)
                {
                    Connect();
                    System.Diagnostics.Debug.WriteLine("Connecting to server!");
                    return;
                }
            }

            for (int i = 0; i < n_ports; i++)
            {
                if (!clientSocket[i].Connected)
                    return;
            }
            try
            {
                // Send data in n sub packages
                int i = 0;
                
                int sub_length = data.Data.Length / n_ports;
                int last_sub_length = data.Data.Length - sub_length * (n_ports - 1);

                var list = new List<int>(n_ports);
                for (i = 0; i < n_ports; i++) list.Add(i);

                using (var countdownEvent = new CountdownEvent(n_ports))
                {
                    for (i = 0; i < n_ports; i++)
                    {
                        int temp_i = i;
                        ThreadPool.QueueUserWorkItem(x => 
                        {
                            subsend_thread(data, sub_length, temp_i, last_sub_length);
                            countdownEvent.Signal();
                        }, list[temp_i]);
                    }
                    countdownEvent.Wait();
                }
                Receive();
            }
            catch (SocketException se)
            {
                System.Diagnostics.Debug.WriteLine("Send Exception:" + se.Message);
            }
        }
        private void subsend_thread(ChannelData data, int sub_length,int i,int length_data_read_last)
        {
            ChannelData small_data = new ChannelData();
            small_data.TimeDate = data.TimeDate;
            small_data.stimpattern = data.stimpattern;

            if (i == n_ports - 1)
            {
                small_data.Data = new int[length_data_read_last];
                Array.Copy(data.Data, i * sub_length, small_data.Data, 0, length_data_read_last);
            }
            else
            {
                small_data.Data = new int[sub_length];
                Array.Copy(data.Data, i * sub_length, small_data.Data, 0, sub_length);
            }
            small_data.timestamp = data.timestamp*n_ports + i;

            // Transform data to json format
            string datastring = JsonConvert.SerializeObject(small_data); // Sending data
            byte[] byteBuffer = Encoding.UTF8.GetBytes(datastring);
            int messageLength = byteBuffer.Length;
            byte[] headerBytes = BitConverter.GetBytes(messageLength);
            if (BitConverter.IsLittleEndian)
                Array.Reverse(headerBytes);

            //System.Diagnostics.Debug.WriteLine(i+ small_data.Data.Length* 100);
                 clientSocket[i].Send(headerBytes, 0, headerBytes.Length, SocketFlags.None);
            clientSocket[i].Send(byteBuffer, 0, byteBuffer.Length, SocketFlags.None);
        }

        public void Receive()
        {
            for (int i = 0; i < n_ports; i++)
            {
                if (clientSocket[i] == null || !clientSocket[i].Connected)
                {
                    System.Diagnostics.Debug.WriteLine("Not connected to server!");
                    return;
                }
            }
            try
            {
                // Receive data (only from socket 0)
                if(clientSocket[0].Available > 0)
                {
                    System.Diagnostics.Debug.WriteLine("Receive message");
                    int charLen = 0;
                    byte[] messageBuffer = new byte[258000]; // This is the size of a data package * 100
                    int bytesRcvd = clientSocket[0].Receive(messageBuffer);
                    char[] chars = new char[bytesRcvd];
                    Decoder dec = Encoding.UTF8.GetDecoder();
                    charLen += dec.GetChars(messageBuffer, 0, bytesRcvd, chars, 0);
                    
                    Dictionary<string, uint[]> receive_dict = JsonConvert.DeserializeObject<Dictionary<string, uint[]>>(new string(chars));
                    uint[] newData = receive_dict["pattern"];

                    for (int i = 0; i < newData.Length / 258; i++)
                    {
                        uint[] subnewData = new uint[258];
                        Array.Copy(newData, i * 258, subnewData, 0, 258);
                        //System.Diagnostics.Debug.WriteLine(string.Join(", ", subnewData));
                        dataMessages.Enqueue(subnewData);
                    }
                }
            }
            catch (SocketException se)
            {
                Disconnect();
                System.Diagnostics.Debug.WriteLine("Receive exception:"+se.Message);
            }
        }

        public void Clear()
        {
            dataQueue.Clear();
            dataMessages.Clear();
        }
        public void Enqueue(ChannelData element)
        {
            if (dataQueue.Count == 50)
                dataQueue.Dequeue();
            dataQueue.Enqueue(element);
        }

        public ChannelData Dequeue()
        {
            if (dataQueue.Count == 0)
                return null;
            return dataQueue.Dequeue();
        }

        public int[] get_current_patterns()
        {
            return new int[16]; // TODO: write function that reads current pattern from DSP
        }

        public int length()
        {
            return dataQueue.Count;
        }

        public int length_messages()
        {
            return dataMessages.Count;
        }

        public void set_probabilities(CMcsUsbFactoryNet factorydev, uint circuit, uint[] probabilities)
        {
            int i;

            for (i = 0; i < 256; i++)
            {
                factorydev.WriteRegister((uint)(0x1A00 + 0x0004 * i), probabilities[i]);
            }

            factorydev.WriteRegister(0x1004, circuit);
            factorydev.WriteRegister(0x1000, 0x0004);
        }

        public void set_pattern_low(CMcsUsbFactoryNet factorydev, uint circuit, uint[] probabilities)
        {
            int i;

            for (i = 0; i < 256; i++)
            {
                factorydev.WriteRegister((uint)(0x1A00 + 0x0004 * i), probabilities[i]);
            }

            factorydev.WriteRegister(0x1004, circuit);
            factorydev.WriteRegister(0x1000, 0x0002);
        }

        public void set_pattern_high(CMcsUsbFactoryNet factorydev, uint circuit, uint[] probabilities)
        {
            int i;

            for (i = 0; i < 256; i++)
            {
                factorydev.WriteRegister((uint)(0x1A00 + 0x0004 * i), probabilities[i]);
            }

            factorydev.WriteRegister(0x1004, circuit);
            factorydev.WriteRegister(0x1000, 0x0003);
        }

        public void sendDataStream()
        {
            ChannelData data;
            if (length() == 0)
                return;

            for (int i = 0; i < n_ports; i++)
            { 
                if (clientSocket[i] == null || !clientSocket[i].Connected)
                {
                    Connect();
                    return;
                }
            }
            var tasks = new List<Task>();

            int flag = 3; // send until queue is empty or 3 packages at once

            while (length() > 0 && flag > 0)
            { 
                data = Dequeue();

                flag -= 1;
                tasks.Add(sendData(data));
                //sendData(data);

                //Thread data_thread = new Thread(() => sendData(data));
                //data_thread.Start();
            }
        }

        public uint[] ReadStimPattern()
        {
            uint[] stimpattern = new uint[0x40];

            CMcsUsbFactoryNet factorydev;
            factorydev = new CMcsUsbFactoryNet();
            lock (_lock)
            {
                if (factorydev.Connect(DspPort, LockMask) == 0)  // if connect call returns zero, connect has been successful
                {
                    int i;
                    for (i = 0; i < 0x40; i++)
                    {
                        stimpattern[i] = factorydev.ReadRegister(0x1E00 + (uint)(0x0004 * i));
                    }
                }
                factorydev.Disconnect();
            }

            

            return stimpattern;
        }

        public int ProcessPackages()
        {
            if (dataMessages.Count == 0)
                return -1;

            CMcsUsbFactoryNet factorydev;
            factorydev = new CMcsUsbFactoryNet();

            lock (_lock)
            {
                if (factorydev.Connect(DspPort, LockMask) == 0)  // if connect call returns zero, connect has been successful
                {
                    uint state;
                    uint[] package;
                    uint command;

                    state = factorydev.ReadRegister(0x1000);
                    if (state != 1)
                    {
                        factorydev.Disconnect();
                        return (int)(state + 1);
                    }
                    package = dataMessages.Dequeue();
                    command = package[0];
                    if (command == 0x0002) // set pattern
                    {
                        set_pattern_low(factorydev, package[1], package.Skip(2).ToArray());
                    }
                    else if (command == 0x0003) // set pattern
                    {
                        set_pattern_high(factorydev, package[1], package.Skip(2).ToArray());
                    }
                    else if (command == 0x0004) // set probability
                    {
                        set_probabilities(factorydev, package[1], package.Skip(2).ToArray());
                    }
                    else // Other command
                    {
                        System.Diagnostics.Debug.WriteLine("Non-standard command: " + command.ToString());

                        factorydev.WriteRegister(0x1004, package[1]);
                        factorydev.WriteRegister(0x1000, package[0]);
                    }
                    /*long time_left = 300000;
                    while (dataMessages.Count > 0 && time_left >= 300000)
                    {

                        System.Diagnostics.Debug.WriteLine("------");
                        System.Diagnostics.Debug.WriteLine(DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond);

                        package = dataMessages.Dequeue();
                        System.Diagnostics.Debug.WriteLine(DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond);
                        command = package[0];
                        if (command == 0x0002) // set pattern
                        {
                            set_pattern_low(factorydev, package[1], package.Skip(2).ToArray());
                        }
                        else if (command == 0x0003) // set pattern
                        {
                            set_pattern_high(factorydev, package[1], package.Skip(2).ToArray());
                        }
                        else if (command == 0x0004) // set probability
                        {
                            set_probabilities(factorydev, package[1], package.Skip(2).ToArray());
                        }
                        else // Other command
                        {
                            System.Diagnostics.Debug.WriteLine("Non-standard command: " + command.ToString());

                            factorydev.WriteRegister(0x1004, package[1]);
                            factorydev.WriteRegister(0x1000, package[0]);
                        }
                        System.Threading.Thread.Sleep(1); // Wait 1000 us (program takes roughly 280 us to process)
                        time_left = factorydev.ReadRegister(0x1004);*/
                        /*
                        while (factorydev.ReadRegister(0x1000) != 0x0001) ;
                        System.Diagnostics.Debug.WriteLine("Time left: " + time_left.ToString());*/
                    //}
                    factorydev.Disconnect();
                }
            }
            return 0;
        }
    }
}
