﻿namespace FB_Example.Properties
{
    using System;
    using System.Collections.Generic;
    class ChannelData
    {
        public ChannelData()
        {
            Data        = null;
            TimeDate    = DateTime.Now.ToString(@"yyyy-MM-dd HH\:mm\:ss");
            stimpattern = new uint[0x40]; // This will be written with the mailbox data 0x1e00-0x1f00
        }

        public int[] Data { get; set; }
        public string TimeDate { get; set; }
        public int timestamp { get; set; }
        public uint[] stimpattern { get; set; }

    }
}
