﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Code has been adapted from: https://stackoverflow.com/questions/15795205/how-to-make-a-vertical-progress-bar

namespace FB_Example.Properties
{
    public class VerticalProgressBar : System.Windows.Forms.ProgressBar
    {
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.Style       |= 0x04;
                return cp;
            }
        }
    }
}
